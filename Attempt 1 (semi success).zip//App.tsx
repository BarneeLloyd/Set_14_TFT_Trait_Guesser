import React, { useState, useRef, useCallback } from 'react';

type TwitchVodPlayerProps = {};

const TwitchVodPlayer: React.FC<TwitchVodPlayerProps> = () => {
  const [vodUrl, setVodUrl] = useState<string>('');
  const [videoId, setVideoId] = useState<string | null>(null);
  const playerRef = useRef<Twitch.Player | null>(null);
  const [playerInitialized, setPlayerInitialized] = useState<boolean>(false);

  const handleInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setVodUrl(event.target.value);
  };

  const extractVideoId = (url: string): string | null => {
    try {
      const urlObject = new URL(url);
      const pathname = urlObject.pathname;
      const parts = pathname.split('/');
      if (parts.length > 2 && parts[1] === 'videos') {
        return parts[2];
      }
      return null;
    } catch (error) {
      console.error("Invalid URL:", error);
      return null;
    }
  };

  const handleLaunch = () => {
    const extractedId = extractVideoId(vodUrl);
    if (extractedId) {
      setVideoId(extractedId);
    } else {
      alert('Invalid Twitch VOD URL. Please provide a valid URL in the format: https://www.twitch.tv/videos/VIDEO_ID');
    }
  };

  const initializePlayer = useCallback(() => {
    if (videoId && !playerInitialized) {
      const options = {
        width: '100%',
        height: '480',
        video: videoId,
        parent: [window.location.hostname],
        controls: false,
        autoplay: false
      };

      // @ts-ignore
      const player = new Twitch.Player('twitch-embed', options);

      playerRef.current = player;
      setPlayerInitialized(true);
    }
  }, [videoId, playerInitialized]);

  React.useEffect(() => {
    if (videoId && !playerInitialized) {
      const script = document.createElement('script');
      script.src = 'https://player.twitch.tv/js/embed/v1.js';
      script.async = true;
      script.onload = initializePlayer;

      document.body.appendChild(script);

      return () => {
        document.body.removeChild(script);
      };
    }
  }, [videoId, initializePlayer, playerInitialized]);

  const rewindTen = () => {
    playerRef.current?.seek(playerRef.current.getCurrentTime() - 10);
  };

  const rewindThirty = () => {
    playerRef.current?.seek(playerRef.current.getCurrentTime() - 30);
  };

  const pauseVideo = () => {
    playerRef.current?.pause();
  };

  const skipTen = () => {
    playerRef.current?.seek(playerRef.current.getCurrentTime() + 10);
  };

  const skipMinute = () => {
    playerRef.current?.seek(playerRef.current.getCurrentTime() + 60);
  };

  const skipFiveMinutes = () => {
    playerRef.current?.seek(playerRef.current.getCurrentTime() + 300);
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100 p-4">
      <h1 className="text-2xl font-bold mb-4 text-gray-800">Twitch VOD Player</h1>
      <div className="w-full max-w-2xl mb-4">
        <label htmlFor="vodUrl" className="block text-gray-700 text-sm font-bold mb-2">
          Twitch VOD URL:
        </label>
        <input
          type="url"
          id="vodUrl"
          className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
          placeholder="https://www.twitch.tv/videos/123456789"
          value={vodUrl}
          onChange={handleInputChange}
        />
      </div>
      <button
        className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
        onClick={handleLaunch}
      >
        Launch
      </button>

      {videoId && (
        <div className="w-full max-w-4xl mt-8">
          <div id="twitch-embed"></div>
          <div className="flex flex-wrap justify-center gap-4 mt-4">
            <button className="bg-purple-500 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline" onClick={rewindTen}>
              Rewind 10s
            </button>
            <button className="bg-purple-500 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline" onClick={rewindThirty}>
              Rewind 30s
            </button>
            <button className="bg-yellow-500 hover:bg-yellow-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline" onClick={pauseVideo}>
              Pause
            </button>
            <button className="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline" onClick={skipTen}>
              Skip 10s
            </button>
            <button className="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline" onClick={skipMinute}>
              Skip 1m
            </button>
            <button className="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline" onClick={skipFiveMinutes}>
              Skip 5m
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default TwitchVodPlayer;